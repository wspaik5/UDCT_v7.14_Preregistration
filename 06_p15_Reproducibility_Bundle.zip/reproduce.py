"""Fresh local QUMOND/OM DF calculations; no preregistered inference."""
from pathlib import Path
import csv,json,hashlib,sys
import numpy as np
from step47_reference import one
D=Path(__file__).resolve().parent
P=[1.499,1.5,1.501]; R=[0.45,0.474097647,0.50]; RA=[0.45,0.466466787396,0.50,float('inf')]
rows=[]
for p in P:
 for r in R:
  iso=one(r,p,float('inf'),96)
  half=one(r,p,0.5,96)
  B=(half-iso)*0.25
  for ra in RA:
   f=iso if np.isinf(ra) else iso+B/(ra*ra)
   rows.append(dict(p=p,energy_label_r_over_a=r,ra_over_a='inf' if np.isinf(ra) else ra,f_DF=f,sign='negative' if f < -1e-10 else ('positive' if f > 1e-10 else 'near_zero'),nodes=96,method='affine_OM_from_f_iso_and_f_ra_0p5'))
with (D/'fresh_df_samples.csv').open('w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
summary={'status':'executed fresh local samples','count':len(rows),'negative_count':sum(x['sign']=='negative' for x in rows),'minimum_f':min(x['f_DF'] for x in rows),'p_values':P,'energy_labels':R,'ra_values':['0.45','0.466466787396','0.50','inf'],'nodes':96,'model':'Step47 shared kernel, spherical isolated simple QUMOND + OM','limits':['Only 36 finite-grid values','Same Step47 physical kernel','Not global positivity or observational validation']}
(D/'fresh_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
