"""UDCT v7.14 exploratory audit 06: local critical-curve derivatives and optimizer cross-check.
Uses shared Step47 physics kernel; exploratory, NOT preregistered or global positivity proof.
Run: python audit06.py
"""
from pathlib import Path
import csv,json
import numpy as np
from scipy.optimize import minimize_scalar
from step47_reference import one
D=Path(__file__).resolve().parent
src=Path('/mnt/data/UDCT_v7.14_Exploratory_Audit_03/critical_vs_p.csv')
if not src.exists():src=D/'critical_vs_p.csv'
with src.open() as f: data=list(csv.DictReader(f))
p=np.array([float(q['p']) for q in data]); ra=np.array([float(q['critical_ra_over_a_n96']) for q in data])
# Nonuniform three-point centered finite differences at p=1.5 with h=.001 and .005
idx={round(x,3):i for i,x in enumerate(p)}
derivs=[]
for h in (.001,.005):
    y0=ra[idx[1.5]];ym=ra[idx[round(1.5-h,3)]];yp=ra[idx[round(1.5+h,3)]]
    derivs.append({'h':h,'slope':(yp-ym)/(2*h),'curvature':(yp-2*y0+ym)/h**2})
# For each energy radius, OM inversion affine: f=iso+B/ra^2. At f=0 ra=sqrt(-B/iso).
# The tangency at minimum f corresponds to maximum of ra_zero(r) if f_iso>0 and B<0.
rows=[]
for pv in (1.499,1.5,1.501):
    cache={}
    def critical(r):
        k=round(float(r),12)
        if k not in cache:
            iso=one(float(r),pv,np.inf,96)
            fhalf=one(float(r),pv,.5,96)
            B=(fhalf-iso)*.25
            cache[k]=float(np.sqrt(-B/iso)) if iso>0 and B<0 else float('nan')
        return cache[k]
    bounds=(.43,.52)
    # Two independent minimizer algorithms applied to the same physical kernel.
    bounded=minimize_scalar(lambda r:-critical(r),bounds=bounds,method='bounded',options={'xatol':1e-7})
    golden=minimize_scalar(lambda r:-critical(r),bracket=(.44,.474,.51),method='golden',options={'xtol':1e-7})
    rows.append({'p':pv,'bounded_r':float(bounded.x),'bounded_ra':float(-bounded.fun),'golden_r':float(golden.x),'golden_ra':float(-golden.fun),'abs_delta_ra':float(abs(bounded.fun-golden.fun)),'evaluations':len(cache)})
    print(rows[-1],flush=True)
with (D/'optimizer_comparison.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with (D/'curve_derivatives.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=derivs[0].keys());w.writeheader();w.writerows(derivs)
summary={'scope':'local exploratory audit, shared Step47 gravity/DF kernel','derivatives':derivs,'optimizer_comparison':rows,'caveats':['Finite difference curvature is sensitive to h and numerical noise','Optimizer comparison does not constitute independent physical validation','Local energy interval only','No global DF positivity proof']}
(D/'results.json').write_text(json.dumps(summary,indent=2))
print('DERIVATIVES',derivs)
