# UDCT v7.14 Formal Preregistration — Protocol 01 (DRAFT)

**Status:** Draft only. Not preregistered, frozen, executed, or published. 29 October 2026 (NZ).

## Provenance and separation
This protocol was written after inspection of archived exploratory Step 40, Step 50, Audit 03, and Audit 06. All values in the next section are **prior exploratory findings**, not prospective predictions. The three original archives remain unchanged.

## Archived exploratory results
- Step 40: isolated spherical simple-QUMOND with Plummer gravitating mass; G=4.30091e-3 pc (km/s)^2/Msun; M=32730 Msun; a=53.3 pc; a0=1.2e-10 m/s^2; tracer rho_p(r)=[1+(r/a)^p]^(-5/p).
- Step 40: central Psi(r)=A r^(3/2)+(k/4)r^2+...; at p=1.5, leading rho'' coefficient cancels and next-order isotropic f(E) has a positive E^(-1/6) term under stated assumptions.
- Step 50: OM local critical ra/a=0.46646678739601644 at p=1.5; energy-label r/a=0.47409755283222904; search interval r/a in [0.25,0.75]. This is not global DF positivity.
- Audit 03: local p sweep [1.49,1.495,1.499,1.5,1.501,1.505] with common Step47 kernel.
- Audit 06: bounded/golden optimizers shared the same physical kernel. Agreement is not independent physical validation.

## Research questions
RQ1: Can an independently derived asymptotic expansion reproduce the sign and exponent of the p=1.5 subleading term, without copying the Step 40 derivation?
RQ2: Can an independently implemented OM inversion reproduce the **local** contact boundary and determine whether other negative lobes occur on a separately defined extended energy domain?
RQ3: How do independent inversion methods and quadrature convergence affect classifications of DF nonnegativity?

## Primary and secondary outcomes
Primary: signed difference between independently derived and archived asymptotic coefficients and powers; local critical ra/a discrepancy between independently implemented inversion and the archived Step 50 benchmark; signs of DF with numerical error estimates on a prespecified finite domain.
Secondary: sensitivity to quadrature order, energy grid, optimization method, and tracer exponent.

## Required prospective lock before execution
The following remain UNLOCKED and must be chosen *before* inspecting any new test output:
1. Exact prospective p values, excluding the six Audit 03 p values for the primary out-of-sample test.
2. Energy domain and grid, including endpoints and convergence refinement; clarify that r/a is an energy label, not a stellar radius.
3. Independent inversion route, derivation and implementation (no import or copy of step47_reference.py for the independent primary result).
4. Numerical tolerances for coefficient comparison, ra/a agreement, quadrature convergence and sign classification; justify tolerances from independent error budgets rather than observed agreement.
5. Error treatment near zero crossings, optimization bracketing and deterministic seed policy.
6. Pass/fail/inconclusive decision table, software versions and hardware/precision constraints.
7. SHA-256 manifest for protocol, scripts and original input archives, with timestamp and archived preregistration DOI.

## Interpretation safeguards
- Local tangency and global nonnegativity are distinct.
- A finite grid with no negative values is not a mathematical proof of all-energy DF positivity.
- Same-kernel quadrature or optimizer comparisons are not independent physics checks.
- Hydrus I-inspired inputs are not star-by-star line-of-sight velocity fitting or observational validation.
- This work does not establish a universal p=1.5 threshold, model stability, superiority over MOND/GQUMOND/dark matter, or a new gravitational theory.
- All failures and inconclusive outcomes must be preserved, not retrospectively relabeled as preregistered predictions.

## Proposed workflow
A. Independently transcribe mathematical model and derive analytic limits; B. freeze numerical specification and tests; C. archive preregistration with DOI before any new primary runs; D. execute locked code; E. release all outputs including failures as post-registration.

## Source archives
- `7.14 Exploratory audit 1~6.zip`
- `7.14 Hessian 1~25.zip`
- `7.14 Hessian 26~50.zip`

**This draft is a planning artifact and must not be uploaded as a completed formal preregistration without locking the open items.**
