# UDCT v7.14 Protocol 01 — Independent asymptotic derivation (pre-lock)

**Status:** Symbolic verification of an already explored asymptotic result; NOT a new prospective numerical experiment. The companion Python script uses SymPy and does not import archived Step 40 or Step 47 code.

## Model and expansion

For the isolated spherical simple-QUMOND Plummer source, define `k=GM/a^3`, `h=sqrt(a0*k)` and central outward potential difference `Psi(r)=A*r^(3/2)+B*r^2+O(r^(5/2))`, with `A=2h/3>0`, `B=k/4>0`. The tracer profile is `rho_p(r)=[1+(r/a)^p]^(-5/p)`; its first small-r term is `1-C*r^p`, `C=5/(p*a^p)>0`.

Introduce `u=(Psi/A)^(2/3)`. Series reversion gives `r=u*[1-(2B/(3A))*u^(1/2)+O(u)]`. Therefore

`rho_p(Psi)=1-C*(Psi/A)^(2p/3)+(2p*C*B/(3A))*(Psi/A)^((2p+1)/3)+...`,

**subject to accounting for competing tracer terms** from `rho_p(r)=1-C*r^p+O(r^(2p))`. At `p=3/2`, these competing terms begin at `Psi^2` and thus occur after the displayed `Psi^(4/3)` correction.

At `p=3/2` the leading `Psi^1` term has zero second derivative, whereas the next term is `+(C*B/A^(7/3))*Psi^(4/3)` and

`rho''(Psi)=(4/9)*(C*B/A^(7/3))*Psi^(-2/3)+... > 0`.

This reproduces the **local asymptotic sign and exponent** already explored in Step 40, via explicit series reversion. It does not prove positivity of the full DF, stability, or an observational fit. The coefficient of the Abel-inverted leading term additionally depends on the exact inversion convention and integration bounds; it is **not** claimed independently validated here.

## What is and is not independent

The derivation is algebraically separate from Step 40 code but starts from the *same physical model and assumed central expansions*. It is an independent symbolic check, not independent physical validation. No new parameter values, energies, or OM contact searches were run.

## Next pre-registration lock

Freeze out-of-sample p values, the energy-label domain, a second inversion algorithm, absolute and relative error tolerances, zero-sign confidence criteria, and software environment **before** running prospective tests. Preserve the original archives unchanged.
