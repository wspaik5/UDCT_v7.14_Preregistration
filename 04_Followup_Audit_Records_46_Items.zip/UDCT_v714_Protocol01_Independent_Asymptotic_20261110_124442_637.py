"""UDCT v7.14 Protocol 01: symbolic-only independent local asymptotic audit.
No finite-energy inversion, prospective parameter sweep, or post-registration tests.
Requires sympy. Execute: python UDCT_v714_Protocol01_Independent_Asymptotic.py
"""
import sympy as s
p,C,A,B,Psi=s.symbols('p C A B Psi',positive=True)
alpha=2*p/3
# Potential Psi=A*r^(3/2)+B*r^2+O(r^(5/2)). Let u=(Psi/A)^(2/3).
# Series inversion r=u*(1-(2/3)*(B/A)*u^(1/2)+O(u)).
u=s.symbols('u',positive=True)
r=u*(1-s.Rational(2,3)*(B/A)*s.sqrt(u))
# rho=1-C*r^p+... ; retain terms linear in B.
leading=-C*u**p
correction=s.expand(-C*u**p*(-p*s.Rational(2,3)*(B/A)*s.sqrt(u)))
# Re-express u=(Psi/A)^(2/3).
sublead=s.simplify(correction.subs(u,(Psi/A)**s.Rational(2,3)))
critical=s.simplify(sublead.subs(p,s.Rational(3,2)))
second=s.simplify(s.diff(critical,Psi,2))
assert s.simplify(second/(s.Rational(4,9)*C*B/A**s.Rational(7,3)*Psi**(-s.Rational(2,3))))==1
print('General subleading term:',sublead)
print('At p=3/2:',critical)
print('Second derivative at p=3/2:',second)
print('Positive for C,A,B,Psi>0:',s.ask(s.Q.positive(second)))
print('STATUS: symbolic derivation only; NO prospective numerical results generated.')
