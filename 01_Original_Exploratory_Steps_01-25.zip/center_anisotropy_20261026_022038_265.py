"""Exploratory Hydrus I constant-beta Newtonian Jeans tests; not a preregistered prediction."""
import numpy as np, pandas as pd, json, hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv')
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
G=4.30091e-3; a=53.3; distance=27600.; Mref=1e6
centers={'literature':(37.389,-79.3089),'sample_median':(float(D.RAdeg.median()),float(D.DEdeg.median()))}
betas=[-1.,-.5,0.,.25]
# Plummer tracer and total-mass Plummer potential, with constant beta
r=np.geomspace(1e-4,2e6,15000)
nu=(1+(r/a)**2)**(-2.5)
Mr=Mref*r**3/(r*r+a*a)**1.5
rows=[]
for cname,(ra0,dec0) in centers.items():
 x=(D.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0))*60
 y=(D.DEdeg.to_numpy(float)-dec0)*60
 R=np.hypot(x,y)*np.pi/(180*60)*distance
 z=np.concatenate(([0.],np.geomspace(1e-4,1e5,1300)))
 rr=np.sqrt(R[:,None]**2+z[None,:]**2)
 nu_los=(1+(rr/a)**2)**(-2.5)
 denom=2*np.trapezoid(nu_los,z,axis=1)
 for beta in betas:
  integrand=nu*G*Mr/r**2*r**(2*beta)
  cum=cumulative_trapezoid(integrand,r,initial=0)
  integral=np.maximum(cum[-1]-cum,0)
  sr2=integral*r**(-2*beta)/nu
  # tail truncation produces numerical underflow only at enormous r, outside observed range
  sr2=np.maximum(sr2,0)
  spl=interp1d(np.log(r),sr2,bounds_error=False,fill_value=(sr2[0],0.))
  val=spl(np.log(np.maximum(rr,1e-4)))
  los=2*np.trapezoid(nu_los*val*(1-beta*(R[:,None]**2)/(rr**2+1e-30)),z,axis=1)/denom
  assert np.all(np.isfinite(los)) and np.all(los>0)
  def objective(t):
   mu,fgmu,fgs,logit,logmass=t
   var=los*np.exp(logmass)/Mref
   p=expit(logit)
   vm=var+e**2; vf=fgs**2+e**2
   m=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
   f=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
   return -np.sum(logsumexp(np.array([m,f]),axis=0))
  bounds=[(65,100),(-100,200),(25,350),(-5,1.5),(np.log(1e3),np.log(1e8))]
  rng=np.random.default_rng(714)
  starts=[]
  for i in range(10):
   t=[80+rng.normal(0,2),rng.uniform(50,110),rng.uniform(70,160),rng.uniform(-2.5,-.7),np.log(rng.uniform(2e5,1.2e6))]
   starts.append(minimize(objective,t,method='L-BFGS-B',bounds=bounds,options={'maxiter':700,'ftol':1e-10}))
  fit=min(starts,key=lambda q:q.fun); t=fit.x
  row={'center':cname,'center_ra_deg':ra0,'center_dec_deg':dec0,'beta':beta,'physically_admissible_constant_beta_for_cored_plummer':beta<=0,'n_stars':len(v),'success':bool(fit.success),'successful_starts':sum(int(s.success) for s in starts),'nll':float(fit.fun),'bic':float(2*fit.fun+5*np.log(len(v))),'mass_total_Msun':float(np.exp(t[4])),'member_mean_kms':float(t[0]),'foreground_mean_kms':float(t[1]),'foreground_sigma_kms':float(t[2]),'member_fraction':float(expit(t[3])),'sigma_los_at_R0_kms':float(np.sqrt(np.exp(t[4])/Mref * np.interp(0, R, los))) if False else None,'at_bounds':bool(any(abs(q-lo)<1e-3 or abs(q-hi)<1e-3 for q,(lo,hi) in zip(t,bounds)))}
  rows.append(row)
  print(cname,beta,'M',round(row['mass_total_Msun']),'BIC',round(row['bic'],3),flush=True)
pd.DataFrame(rows).to_csv(P/'results.csv',index=False)
summary={'status':'PRE-PREREGISTRATION EXPLORATORY; model-selection BIC values are in-sample and beta values fixed per fit','source_data_sha256':hashlib.sha256((P.parent.parent/'table2.txt').read_bytes()).hexdigest(),'source_reference':'Koposov et al. 2018 MNRAS 479 5343 Table 1','assumptions':{'distance_kpc':27.6,'plummer_projected_half_light_radius_pc':a,'total_gravitating_mass':'freely fitted, not stellar-only','tracer':'Plummer','mass_profile':'Plummer same scale a','anisotropy':'constant beta; beta>0 violates central cusp-slope anisotropy condition for cored Plummer tracer','foreground':'single free Gaussian; velocity-only membership mixture','no_gradient':True},'results':rows,'warnings':['No actual stellar-only Newtonian model or modified-gravity calculation','Constant-beta cored Plummer beta>0 shown solely as mathematically fitted diagnostic, not physically admissible','Does not model proper motion, binaries, selection function, spatial membership prior, LMC external field, or 3D Hessian','Not a complete distribution-function positivity check for all beta<=0','Do not interpret BIC variation as evidence for modified gravity']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
