from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
root=P.parent
D=pd.read_csv(root/'run1/data_audit.csv')
v=D.HRV.to_numpy(float);e=D.e_HRV.to_numpy(float)
ra=D.RAdeg.to_numpy(float); dec=D.DEdeg.to_numpy(float)
ra0=float(np.median(ra));dec0=float(np.median(dec))
ang=np.hypot((ra-ra0)*np.cos(np.deg2rad(dec0)),dec-dec0)*np.pi/180
G=4.30091e-3
bounds=[(65,100),(-100,200),(25,350),(-5,1.5),(np.log(1e3),np.log(1e8))]

def fit(dist,a):
 R=ang*dist
 def obj(t):
  mu,fgmu,fgs,lg,lnm=t; mass=np.exp(lnm)
  var=(3*np.pi/64)*G*mass/a/np.sqrt(1+(R/a)**2)
  p=expit(lg); vm=var+e**2;vf=fgs**2+e**2
  m=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
  f=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
  return -np.sum(logsumexp(np.stack((m,f)),axis=0))
 starts=[[80.88,82.14,104,-1.3,np.log(538109)], [80,50,100,-1.2,np.log(3e5)],[82,90,150,-1.5,np.log(8e5)],[78,80,75,-2,np.log(1e6)]]
 fits=[minimize(obj,t,method='L-BFGS-B',bounds=bounds,options={'maxiter':700,'ftol':1e-10}) for t in starts]
 b=min(fits,key=lambda z:z.fun);t=b.x
 return {'distance_kpc':dist/1000,'plummer_a_pc':a,'nll':float(b.fun),'bic':float(2*b.fun+5*np.log(len(v))),'mass_Msun':float(np.exp(t[4])),'sigma_los_center_kms':float(np.sqrt((3*np.pi/64)*G*np.exp(t[4])/a)),'member_fraction':float(expit(t[3])),'success':bool(b.success),'successful_starts':sum(bool(z.success) for z in fits),'at_bounds':bool(any(abs(q-lo)<1e-3 or abs(q-hi)<1e-3 for q,(lo,hi) in zip(t,bounds)))}
rows=[fit(d,a) for d in (25000,28000,31000) for a in (40,53.3,70)]
pd.DataFrame(rows).to_csv(P/'scale_distance_results.csv',index=False)
summary={'status':'exploratory, pre-preregistration','data_sha256':hashlib.sha256((root.parent/'table2.txt').read_bytes()).hexdigest(),'n':len(v),'center_proxy_deg':[ra0,dec0],'assumptions':'isotropic self-consistent Plummer total gravitating mass, Gaussian foreground, velocity-only membership; same likelihood as run5','results':rows,'limitations':['Distance and Plummer scale varied as fixed scenarios, not inferred from photometry','No stellar-only mass, modified gravity, anisotropy, 3D Hessian, or preregistered test','Optimizer success does not establish global optimum']}
(P/'scale_distance_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(pd.DataFrame(rows).to_string(index=False))
