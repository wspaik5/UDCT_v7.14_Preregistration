import numpy as np,pandas as pd,json,hashlib
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
from pathlib import Path
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv'); v=D.HRV.to_numpy(float); er=D.e_HRV.to_numpy(float)
ra0=D.RAdeg.median(); dec0=D.DEdeg.median(); x=(D.RAdeg.to_numpy()-ra0)*np.cos(np.deg2rad(dec0))*60;y=(D.DEdeg.to_numpy()-dec0)*60
baseline=json.loads((P.parent/'run2/mixture_results.json').read_text())
rows=[]
for fgwidth in [60.,100.,150.]:
 for escale in [.8,1.,1.2]:
  e=er*escale
  for grad in [False,True]:
   def obj(t):
    mu,s,fgmu,logit=t[:4]; mean=mu+(t[4]*x+t[5]*y if grad else 0);pi=expit(logit)
    a=np.log(pi)-.5*(np.log(2*np.pi*(s*s+e*e))+(v-mean)**2/(s*s+e*e))
    b=np.log1p(-pi)-.5*(np.log(2*np.pi*(fgwidth**2+e*e))+(v-fgmu)**2/(fgwidth**2+e*e))
    return -np.sum(np.logaddexp(a,b))
   bounds=[(65,100),(.05,20),(-100,200),(-5,1.5)]+([(-2,2),(-2,2)] if grad else [])
   starts=[[80,2.6,82,-1.25]+([.6,.2] if grad else []),[81,1.0,70,-1.5]+([0,0] if grad else [])]
   sols=[minimize(obj,s,method='L-BFGS-B',bounds=bounds,options={'maxiter':600,'ftol':1e-9}) for s in starts]
   best=min(sols,key=lambda z:z.fun); t=best.x; k=len(t)
   rows.append(dict(fg_sigma_fixed=fgwidth,error_multiplier=escale,gradient=grad,converged=bool(best.success),nll=float(best.fun),bic=float(2*best.fun+k*np.log(len(v))),member_mean=float(t[0]),member_sigma=float(t[1]),foreground_mean=float(t[2]),member_fraction=float(expit(t[3])),gx=float(t[4]) if grad else 0.,gy=float(t[5]) if grad else 0.,at_bound=any(abs(z-lo)<1e-3 or abs(z-hi)<1e-3 for z,(lo,hi) in zip(t,bounds))))
R=pd.DataFrame(rows);R.to_csv(P/'sensitivity_grid.csv',index=False)
S=[]
for (f,e),g in R.groupby(['fg_sigma_fixed','error_multiplier']):
 a=g[g.gradient==False].iloc[0];b=g[g.gradient==True].iloc[0];S.append(dict(fg_sigma_fixed=f,error_multiplier=e,delta_BIC_gradient_minus_flat=float(b.bic-a.bic),sigma_flat=float(a.member_sigma),sigma_gradient=float(b.member_sigma),gradient_magnitude=float(np.hypot(b.gx,b.gy)),any_at_bound=bool(a.at_bound or b.at_bound),both_converged=bool(a.converged and b.converged)))
T=pd.DataFrame(S);T.to_csv(P/'comparison.csv',index=False)
summary={'status':'EXPLORATORY; fixed foreground widths are sensitivity assumptions, not measured truths','n':len(v),'data_sha256':hashlib.sha256((P.parent.parent/'table2.txt').read_bytes()).hexdigest(),'grid_cases':len(T),'fits':len(R),'converged':int(R.converged.sum()),'gradient_bic_better':int((T.delta_BIC_gradient_minus_flat<0).sum()),'delta_BIC_range':list(map(float,[T.delta_BIC_gradient_minus_flat.min(),T.delta_BIC_gradient_minus_flat.max()])), 'member_sigma_flat_range':list(map(float,[T.sigma_flat.min(),T.sigma_flat.max()])), 'member_sigma_gradient_range':list(map(float,[T.sigma_gradient.min(),T.sigma_gradient.max()])), 'any_bound_cases':int(T.any_at_bound.sum()),'caveats':['Fixed foreground widths not fit; BIC comparisons only within same foreground/error scenario','No spatial selection or stellar metallicity membership model','No Jeans or Hessian physics fit','Original logodds excluded from likelihood','Exploratory grid chosen after inspecting earlier results; cannot be called preregistered']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));print(T.to_string(index=False))
