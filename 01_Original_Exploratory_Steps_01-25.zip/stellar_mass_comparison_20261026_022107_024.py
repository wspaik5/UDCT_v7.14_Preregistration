"""UDCT v7.14 exploratory fixed-total-mass profile likelihood; not a stellar-mass measurement."""
import numpy as np,pandas as pd,json,hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv')
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
ra0,dec0=37.389,-79.3089; a=53.3; dist=27600.; G=4.30091e-3; Mref=1e6
R=np.hypot((D.RAdeg.to_numpy()-ra0)*np.cos(np.deg2rad(dec0)),D.DEdeg.to_numpy()-dec0)*np.pi/180*dist
r=np.geomspace(1e-4,2e6,10000); z=np.r_[0.,np.geomspace(1e-4,1e5,1000)]; rr=np.hypot(R[:,None],z[None,:]); nu=(1+(r/a)**2)**-2.5; nu_los=(1+(rr/a)**2)**-2.5; denom=2*np.trapezoid(nu_los,z,axis=1)
Mr=Mref*r**3/(r*r+a*a)**1.5
M_V=-4.71; M_Vsun=4.83
L_V=10**(0.4*(M_Vsun-M_V))
upsilon_grid=[0.5,1,2,3,5,10,30,100]
mass_grid=[L_V*x for x in upsilon_grid] + [5.324885882745674e5]
rows=[]
for beta in [-1.,-.5,0.]:
 integ=nu*G*Mr/r**2*r**(2*beta)
 cum=cumulative_trapezoid(integ,r,initial=0); sr2=np.maximum(cum[-1]-cum,0)*r**(-2*beta)/nu
 spl=interp1d(np.log(r),np.maximum(sr2,0),bounds_error=False,fill_value=(sr2[0],0.))
 los=2*np.trapezoid(nu_los*spl(np.log(np.maximum(rr,1e-4)))*(1-beta*R[:,None]**2/(rr**2+1e-30)),z,axis=1)/denom
 assert np.all(los>0)
 for mass in mass_grid:
  vm=los*(mass/Mref)+e*e
  def objective(t):
   mu,fgmu,fgs,logit=t; p=expit(logit); vf=fgs**2+e*e
   member=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
   fore=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
   return float(-np.sum(logsumexp(np.stack((member,fore)),axis=0)))
  bounds=[(65,100),(-100,200),(25,350),(-8,1.5)]
  rng=np.random.default_rng(714+int(mass)+int((beta+1)*10))
  starts=[[80.5,82,104,-1.3],[81,80,110,-2.5],[80,85,100,-4]]
  starts += [[rng.uniform(76,85),rng.uniform(60,100),rng.uniform(70,150),rng.uniform(-4,-.8)] for _ in range(3)]
  fits=[minimize(objective,s,method='L-BFGS-B',bounds=bounds,options={'maxiter':500,'ftol':1e-10}) for s in starts]
  fit=min(fits,key=lambda f:f.fun); t=fit.x
  rows.append({'beta':beta,'total_mass_Msun':mass,'assumed_stellar_ML':float(mass/L_V),'scenario':'stellar_only' if mass != 5.324885882745674e5 else 'reference_free_total','nll':fit.fun,'member_fraction':float(expit(t[3])),'member_mean_kms':t[0],'foreground_sigma_kms':t[2],'success':bool(fit.success),'successful_starts':sum(f.success for f in fits),'member_fraction_at_lower_bound':abs(t[3]-bounds[3][0])<.001,'sigma_los_center_kms':float(np.sqrt(np.interp(0,R,los)*mass/Mref)) if False else float(np.sqrt(np.interp(0,np.sort(R),los[np.argsort(R)])*mass/Mref))})
  print(beta,mass,round(fit.fun,3),round(float(expit(t[3])),4),flush=True)
res=pd.DataFrame(rows); res['delta_2logL_vs_best_same_beta']=res.groupby('beta').nll.transform(lambda s:2*(s-s.min()))
res.to_csv(P/'stellar_only_grid.csv',index=False)
summary={'status':'PRE-PREREGISTRATION EXPLORATORY', 'M_V':M_V, 'M_Vsun_assumed':M_Vsun, 'luminosity_Lsun':L_V,'stellar_ML_grid':upsilon_grid,'note':'Mass in stellar-only scenarios is fixed to observed V-band luminosity times assumed M/L; this is a hypothetical all-stellar Newtonian mass, NOT a measured stellar mass. Foreground and mixture fractions reoptimized.','caveats':['No independent stellar-population M/L inference','Velocity-only mixture membership can collapse','Fixed beta is not fitted and constant positive beta excluded','Potential Plummer mass scale equal to tracer projected half-light scale','No spatial membership, selection function, binaries or Hessian','Exploratory not preregistered']}
for beta,g in res.groupby('beta'):
    best=g.loc[g.nll.idxmin()]; ref=g[g.scenario=='reference_free_total'].iloc[0]
    summary[str(beta)]={'best_tested_mass_Msun':float(best.total_mass_Msun),'best_tested_nll':float(best.nll),'reference_total_mass_Msun':float(ref.total_mass_Msun),'reference_nll':float(ref.nll),'scenarios':{str(float(q)):{'mass_Msun':float(row.total_mass_Msun),'delta_2logL_vs_reference':float(2*(row.nll-ref.nll)),'member_fraction':float(row.member_fraction)} for q in upsilon_grid for _,row in g[np.isclose(g.assumed_stellar_ML,q,rtol=1e-8)].iterrows()}}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
