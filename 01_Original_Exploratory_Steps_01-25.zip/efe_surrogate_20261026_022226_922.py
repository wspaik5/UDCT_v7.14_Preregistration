"""Exploratory scalar EFE screening surrogate, NOT an AQUAL/QUMOND field solution."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import expit,logsumexp
P=Path(__file__).resolve().parent
D=pd.read_csv(P/'hydrus_input.csv'); v=D.HRV.to_numpy(float);e=D.e_HRV.to_numpy(float)
a=53.3; dist=27600.;G=4.30091e-3; A0=1.2e-10*3.085677581491367e16/1e6
L=10**((4.83+4.71)/2.5); ra0,dec0=37.389,-79.3089
R=np.hypot((D.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0)),D.DEdeg.to_numpy(float)-dec0)*np.pi/10800*dist
r=np.geomspace(1e-3,2e6,6000);nu=(1+(r/a)**2)**(-2.5)
z=np.r_[0,np.geomspace(1e-3,1e5,450)];rr=np.sqrt(R[:,None]**2+z[None,:]**2);nu_los=(1+(rr/a)**2)**(-2.5)
den=2*np.trapezoid(nu_los,z,axis=1)
def nu_func(y,law):
 y=np.maximum(y,1e-15)
 if law=='simple':return .5*(1+np.sqrt(1+4/y))
 if law=='standard':return np.sqrt(.5*(1+np.sqrt(1+4/y**2)))
 raise ValueError(law)
def proj_disp(g):
 I=cumulative_trapezoid(nu*g,r,initial=0);sr2=np.maximum((I[-1]-I)/nu,0)
 it=interp1d(np.log(r),sr2,bounds_error=False,fill_value=(sr2[0],0.))
 return np.maximum(2*np.trapezoid(nu_los*it(np.log(np.maximum(rr,1e-3))),z,axis=1)/den,1e-10)
def fit(proj):
 def obj(t):
  mu,fgmu,fgs,logit=t; vm=proj+e**2;vf=fgs**2+e**2;p=expit(logit)
  mem=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
  fg=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
  return -np.sum(logsumexp(np.array([mem,fg]),axis=0))
 starts=[[80.5,82,105,-1.2],[81,80,95,-1.4],[79,85,120,-1.1]]
 fs=[minimize(obj,s,method='L-BFGS-B',bounds=[(65,100),(-100,200),(25,350),(-5,1.5)],options={'maxiter':220,'ftol':1e-9}) for s in starts]
 best=min(fs,key=lambda x:x.fun)
 return float(best.fun),bool(best.success),sum(int(f.success) for f in fs),best.x
rows=[]
for ml in [1,2,5,10]:
 gN=G*(L*ml)*r/(r*r+a*a)**1.5
 for law in ['Newtonian','simple','standard']:
  for ext in ([0] if law=='Newtonian' else [0,.03,.1,.3,1.0,3.0]):
   # radial surrogate: g = nu(sqrt(gN^2+gext^2)/a0)*gN ; no vector or PDE treatment
   g=gN if law=='Newtonian' else nu_func(np.hypot(gN/A0,ext),law)*gN
   pr=proj_disp(g);nll,ok,nstarts,x=fit(pr)
   rows.append({'law':law,'ML_V':ml,'g_ext_over_a0':ext,'nll':nll,'bic':2*nll+4*np.log(len(v)),'median_sigma_los_kms':float(np.median(np.sqrt(pr))),'success':ok,'successful_starts':nstarts,'member_fraction':float(expit(x[3]))})
   print(law,ml,ext,round(nll,4),flush=True)
T=pd.DataFrame(rows);T.to_csv(P/'efe_sensitivity.csv',index=False)
summary={'status':'v7.14 pre-prereg exploratory','warning':'SCALAR EFE SURROGATE ONLY; NOT a self-consistent AQUAL, QUMOND or GQUMOND solution. EFE generally breaks spherical symmetry; do not use as physical EFE inference.','equation':'g_int(r)=g_N(r)*nu(sqrt((g_N(r)/a0)^2+(g_ext/a0)^2)); scalar surrogate, no vector cross term or external-field subtraction','source':'Koposov et al. 2018 CDS J/MNRAS/479/5343 table2; 139 stars','sha256':hashlib.sha256((P/'hydrus_input.csv').read_bytes()).hexdigest(),'conditions':len(rows),'converged':int(T.success.sum()),'results':rows,'caveats':['No external-field direction or 3D elliptic PDE solution','No Hessian or 24 bracket audit','Constant isotropic Plummer stellar tracer and potential projection','Velocity-only mixture with reoptimized foreground','No spatial selection, binaries, anisotropy, or chemical membership','Trial external-field amplitudes not observed measurements','Model comparison is conditional, not a likelihood-ratio p-value']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
