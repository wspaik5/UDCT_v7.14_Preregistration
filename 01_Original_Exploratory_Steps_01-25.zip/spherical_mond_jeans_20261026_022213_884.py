"""Exploratory isolated spherical AQUAL algebraic MOND versus Newtonian stellar-only Jeans, same likelihood."""
import numpy as np, pandas as pd, json, hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import expit,logsumexp
P=Path(__file__).resolve().parent
D=pd.read_csv(P/'hydrus_input.csv')
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
a=53.3; dist=27600.; G=4.30091e-3 # pc (km/s)^2 / Msun
# a0 1.2e-10 m/s^2 to (km/s)^2 / pc
A0=1.2e-10*3.085677581491367e16/1e6
L=10**((4.83-(-4.71))/2.5)
ra0,dec0=37.389,-79.3089
R=np.hypot((D.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0)),D.DEdeg.to_numpy(float)-dec0)*np.pi/10800*dist
r=np.geomspace(1e-3,2e6,7000)
nu=(1+(r/a)**2)**(-2.5)
z=np.r_[0,np.geomspace(1e-3,1e5,550)]
rr=np.sqrt(R[:,None]**2+z[None,:]**2)
nu_los=(1+(rr/a)**2)**(-2.5)
den=2*np.trapezoid(nu_los,z,axis=1)
rows=[]
for ml in [1.,2.,5.,10.]:
 M=L*ml
 gN=G*M*r/(r*r+a*a)**1.5
 for law in ['Newtonian','MOND_simple','MOND_standard']:
  if law=='Newtonian': g=gN
  elif law=='MOND_simple': g=.5*(gN+np.sqrt(gN*gN+4*A0*gN))
  else: g=np.sqrt(.5*(gN*gN+np.sqrt(gN**4+4*gN*gN*A0*A0)))
  integral=cumulative_trapezoid(nu*g,r,initial=0)
  sr2=np.maximum((integral[-1]-integral)/nu,0)
  interpolator=interp1d(np.log(r),sr2,bounds_error=False,fill_value=(sr2[0],0.))
  proj=2*np.trapezoid(nu_los*interpolator(np.log(np.maximum(rr,1e-3))),z,axis=1)/den
  def obj(t):
   mu,fgmu,fgs,logit=t
   vm=proj+e**2; vf=fgs**2+e**2
   p=expit(logit)
   member=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
   fg=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
   return -np.sum(logsumexp(np.array([member,fg]),axis=0))
  bounds=[(65,100),(-100,200),(25,350),(-5,1.5)]
  starts=[[80.5,82,105,-1.2],[81,80,95,-1.4],[79,85,120,-1.1]]
  fits=[minimize(obj,s,method='L-BFGS-B',bounds=bounds,options={'maxiter':250,'ftol':1e-9}) for s in starts]
  fit=min(fits,key=lambda q:q.fun)
  row={'law':law,'stellar_ML_V':ml,'stellar_mass_Msun':M,'nll':float(fit.fun),'bic':float(2*fit.fun+4*np.log(len(v))),'mean_velocity_kms':float(fit.x[0]),'foreground_sigma_kms':float(fit.x[2]),'mixture_member_fraction':float(expit(fit.x[3])),'success':bool(fit.success),'successful_starts':sum(int(f.success) for f in fits),'median_intrinsic_los_dispersion_kms':float(np.median(np.sqrt(proj)))}
  rows.append(row); print(law,ml,'NLL',round(fit.fun,3),'median_sigma',round(row['median_intrinsic_los_dispersion_kms'],3),flush=True)
T=pd.DataFrame(rows); T.to_csv(P/'comparison.csv',index=False)
summary={'status':'exploratory before v7.14 preregistration','input_sha256':hashlib.sha256((P/'hydrus_input.csv').read_bytes()).hexdigest(),'source':'Koposov et al. 2018 CDS J/MNRAS/479/5343 table2, 139 stars','model':'Isolated spherical AQUAL algebraic MOND field with simple or standard mu, Plummer stellar mass and tracer, isotropic Jeans, fixed stellar M/L, velocity-only 2 Gaussian member/foreground mixture','a0_m_s2':1.2e-10,'L_V_Lsun':L,'geometry':{'center_RA_deg':ra0,'center_Dec_deg':dec0,'distance_pc':dist,'Plummer_a_pc':a},'results':rows,'caveats':['This is NOT a 3D GQUMOND/Hessian solution; isolated spherical AQUAL algebraic relations only.','No external-field effect, tides, binaries, metallicity/spatial selection, or physical DF positivity proof for MOND.','Plummer light radius is assumed as scale radius, and M/L are trial values.','Model-dependent membership mixture and simple Gaussian foreground.','No uncertainty interval, no evidence calculation, no out-of-sample test.','Models with different M/L are not a joint optimized M/L fit.']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
