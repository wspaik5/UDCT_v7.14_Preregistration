"""Exploratory isotropic self-consistent Plummer Newtonian Jeans LOS model.
A single total gravitating Plummer mass M is fitted; NOT a stellar-only mass measurement.
"""
from pathlib import Path
import numpy as np, pandas as pd, json, hashlib
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv')
raw=P.parent.parent/'table2.txt'
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
ra0=float(D.RAdeg.median()); dec0=float(D.DEdeg.median())
x=(D.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0))*60
z=(D.DEdeg.to_numpy(float)-dec0)*60
R=np.hypot(x,z)*np.pi/(180*60)*28000 # pc, assumed 28 kpc
A=53.3 # pc, assumed Plummer projected half-light radius
G=4.30091e-3 # pc (km/s)^2 / Msun
# sigma_los^2(R) = (3 pi / 64) G M / a / sqrt(1+(R/a)^2)

def solve(mode,seed=714,nstarts=12):
 def obj(t):
  mu,fgmu,fgs,logit=t[:4]
  if mode=='plummer':
   mass=np.exp(t[4]); var=(3*np.pi/64)*G*mass/A/np.sqrt(1+(R/A)**2)
  else: var=t[4]**2+np.zeros_like(R)
  p=expit(logit)
  vm=var+e**2; vf=fgs**2+e**2
  a=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
  b=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
  return -np.sum(logsumexp(np.array([a,b]),axis=0))
 bounds=[(65,100),(-100,200),(25,350),(-5,1.5)]+([(np.log(1e3),np.log(1e8))] if mode=='plummer' else [(.05,20)])
 rng=np.random.default_rng(seed)
 fits=[]
 for i in range(nstarts):
  t=[80+rng.normal(0,3),rng.uniform(0,100),rng.uniform(60,170),rng.uniform(-2.5,-.5),rng.uniform(np.log(1e5),np.log(1e7)) if mode=='plummer' else rng.uniform(1,7)]
  fits.append(minimize(obj,t,method='L-BFGS-B',bounds=bounds,options={'maxiter':1000,'ftol':1e-10}))
 best=min(fits,key=lambda a:a.fun)
 t=best.x
 d={'success':bool(best.success),'nll':float(best.fun),'bic':float(2*best.fun+len(t)*np.log(len(v))),'mu_kms':float(t[0]),'foreground_mu_kms':float(t[1]),'foreground_sigma_kms':float(t[2]),'member_fraction':float(expit(t[3])),'at_bounds':bool(any(abs(q-lo)<1e-3 or abs(q-hi)<1e-3 for q,(lo,hi) in zip(t,bounds))),'successful_starts':int(sum(f.success for f in fits))}
 if mode=='plummer':
  M=float(np.exp(t[4]));d.update({'plummer_total_gravitating_mass_Msun':M,'sigma_los_center_kms':float(np.sqrt((3*np.pi/64)*G*M/A)),'sigma_los_at_a_kms':float(np.sqrt((3*np.pi/64)*G*M/A/np.sqrt(2)))})
 else:d['constant_sigma_kms']=float(t[4])
 return d
constant=solve('constant'); plummer=solve('plummer')
result={'status':'PRE-PREREGISTRATION EXPLORATORY only','data_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'n_stars':len(v),'assumptions':{'distance_pc':28000,'plummer_a_pc':A,'center_proxy_median_RA_Dec_deg':[ra0,dec0],'foreground':'free single Gaussian','member':'Gaussian with heteroscedastic observational error','anisotropy_beta':0,'potential':'self-consistent Plummer total mass; not independently measured stellar mass','selection':'velocity-only mixture; no spatial membership prior','gradient':'none'},'constant':constant,'newtonian_plummer':plummer,'delta_BIC_plummer_minus_constant':plummer['bic']-constant['bic'],'warnings':['This is a simplified Newtonian reference, NOT a dark-matter-free stellar-only fit or full realistic Jeans model','Fitted gravitating mass can absorb any dark matter; it cannot distinguish gravity theories','Center is median sky position, not literature photometric center','Distance and scale radius are assumptions; neither is fitted here','The two models have the same number of free parameters; BIC comparison is exploratory and in-sample','No Hessian, no modified gravity, no independent preregistered prediction']}
(P/'newtonian_jeans_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
