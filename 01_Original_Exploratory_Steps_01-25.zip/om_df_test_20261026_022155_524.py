"""UDCT v7.14 exploratory physically positive Osipkov-Merritt Plummer DF test."""
import numpy as np,pandas as pd,json,hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import expit,logsumexp
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv')
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
a=53.3; dist=27600.; G=4.30091e-3; Mref=1e6
ra0,dec0=37.389,-79.3089
R=np.hypot((D.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0)),D.DEdeg.to_numpy(float)-dec0)*np.pi/10800*dist
r=np.geomspace(1e-3,2e6,11000)
nu=(1+(r/a)**2)**(-2.5)
Mr=Mref*r**3/(r*r+a*a)**1.5
z=np.r_[0,np.geomspace(1e-3,1e5,850)]
rr=np.sqrt(R[:,None]**2+z[None,:]**2)
nu_los=(1+(rr/a)**2)**(-2.5)
denom=2*np.trapezoid(nu_los,z,axis=1)
rows=[]
for ratio in [float('inf'),5.,2.,1.]:
 ra=ratio*a
 if np.isinf(ra):
  integrating=nu*G*Mr/r**2
  factor=np.ones_like(r)
  beta=np.zeros_like(rr)
 else:
  integrating=nu*(r*r+ra*ra)*G*Mr/r**2
  factor=r*r+ra*ra
  beta=rr*rr/(rr*rr+ra*ra)
 cum=cumulative_trapezoid(integrating,r,initial=0)
 sr2=np.maximum((cum[-1]-cum)/factor/nu,0)
 spl=interp1d(np.log(r),sr2,bounds_error=False,fill_value=(sr2[0],0.))
 sr_los=spl(np.log(np.maximum(rr,1e-3)))
 projected=2*np.trapezoid(nu_los*sr_los*(1-beta*R[:,None]**2/np.maximum(rr**2,1e-20)),z,axis=1)/denom
 assert np.isfinite(projected).all() and (projected>0).all()
 def objective(t):
  mu,fgmu,fgs,logit,logmass=t
  vm=projected*np.exp(logmass)/Mref+e**2
  vf=fgs**2+e**2
  p=expit(logit)
  m=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
  f=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
  return -np.sum(logsumexp(np.array([m,f]),axis=0))
 bounds=[(65,100),(-100,200),(25,350),(-5,1.5),(np.log(1e3),np.log(1e8))]
 starts=[[80.5,82,105,-1.2,np.log(5.3e5)],[81,80,95,-1.4,np.log(8e5)],[79,85,120,-1.1,np.log(3e5)],[80,70,130,-2,np.log(1e6)]]
 fits=[minimize(objective,s,method='L-BFGS-B',bounds=bounds,options={'maxiter':500,'ftol':1e-10}) for s in starts]
 fit=min(fits,key=lambda q:q.fun)
 t=fit.x
 row={'anisotropy_radius_over_a':'infinity' if np.isinf(ratio) else ratio,'df_positive_by_analytic_sufficient_condition':True,'success':bool(fit.success),'successful_starts':sum(int(q.success) for q in fits),'nll':float(fit.fun),'bic':float(2*fit.fun+5*np.log(len(v))),'mass_total_Msun':float(np.exp(t[4])),'member_mean_kms':float(t[0]),'foreground_sigma_kms':float(t[2]),'member_fraction':float(expit(t[3])),'sigma_los_at_first_catalog_star_kms':float(np.sqrt(projected[0]*np.exp(t[4])/Mref)),'beta_at_a':0 if np.isinf(ratio) else float(1/(1+ratio*ratio))}
 rows.append(row); print(row,flush=True)
pd.DataFrame(rows).to_csv(P/'om_comparison.csv',index=False)
summary={'status':'EXPLORATORY pre-preregistration','data_sha256':hashlib.sha256((P.parent.parent/'table2.txt').read_bytes()).hexdigest(),'model':'Self-consistent Plummer tracer and total gravitating Plummer mass, Osipkov-Merritt anisotropy beta(r)=r^2/(r^2+r_a^2); single Gaussian foreground mixture','physical_df_proof':'For r_a >= a, augmented density rho_Q(psi)=rho0[(1-a^2/r_a^2)(psi/psi0)^5+(a^2/r_a^2)(psi/psi0)^3]. Both polynomial coefficients are nonnegative; Eddington inversion yields a sum of nonnegative terms proportional to Q^(7/2) and Q^(3/2). Hence f(Q)>=0 for 0<Q<psi0. Isotropic limit likewise positive. This is a sufficient constructive condition, not a claim about all r_a<a.','caveats':['Total gravitating mass freely fitted, not stellar-only','Velocity-only membership; chemical and spatial selection not included in this particular comparison','Anisotropy radius fixed per fit, not inferred','Positive DF for self-consistent Plummer potential, not a generic modified gravity proof','No 3D Hessian or modified-gravity test','Numerical quadrature finite upper radius and line-of-sight truncation'],'results':rows}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
