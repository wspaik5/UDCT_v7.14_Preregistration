import numpy as np,pandas as pd,json,hashlib
from pathlib import Path
from scipy.optimize import minimize
from scipy.special import expit,logsumexp
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv'); v=D.HRV.to_numpy(float);e=D.e_HRV.to_numpy(float);ra=D.RAdeg.to_numpy(float);dec=D.DEdeg.to_numpy(float)
x=(ra-np.median(ra))*np.cos(np.deg2rad(np.median(dec)))*60;y=(dec-np.median(dec))*60
prev=json.loads((P.parent/'run2/mixture_results.json').read_text())
def vec(z,g):
 p=z['parameters'];return np.array([p['member_mean_kms'],p['member_intrinsic_sigma_kms'],p['foreground_mean_kms'],p['foreground_intrinsic_sigma_kms'],np.log(p['mixture_member_fraction']/(1-p['mixture_member_fraction']))]+([p['gradient_x_kms_arcmin'],p['gradient_y_kms_arcmin']] if g else []))
base=[vec(prev['flat'],False),vec(prev['gradient'],True)]
def fit(ids,g,start):
 vv=v[ids];ee=e[ids];xx=x[ids];yy=y[ids];n=len(ids)
 def obj(t):
  mu,s,fm,fs,logit=t[:5]; pi=expit(logit);mm=mu+(t[5]*xx+t[6]*yy if g else 0)
  a=np.log(pi)-.5*(np.log(2*np.pi*(s*s+ee*ee))+(vv-mm)**2/(s*s+ee*ee))
  b=np.log1p(-pi)-.5*(np.log(2*np.pi*(fs*fs+ee*ee))+(vv-fm)**2/(fs*fs+ee*ee))
  return -np.sum(logsumexp(np.array([a,b]),axis=0))
 bounds=[(65,100),(.05,20),(-100,200),(25,350),(-5,1.5)]+([(-2,2),(-2,2)] if g else [])
 r=min((minimize(obj,t,method='L-BFGS-B',bounds=bounds,options={'maxiter':400,'ftol':1e-8}) for t in start),key=lambda a:a.fun)
 return dict(success=bool(r.success),sigma=float(r.x[1]),mu=float(r.x[0]),gradient=float(np.hypot(*r.x[5:7])) if g else 0,bic=float(2*r.fun+len(r.x)*np.log(n)),bound=bool(any(abs(z-a)<1e-3 or abs(z-b)<1e-3 for z,(a,b) in zip(r.x,bounds))))
rng=np.random.default_rng(7142026);rows=[];N=80
for j in range(N):
 ids=rng.integers(0,len(v),len(v)); ff=fit(ids,False,[base[0]]); gg=fit(ids,True,[base[1],np.r_[base[0],0.,0.]])
 rows.append(dict(replicate=j+1,flat_sigma=ff['sigma'],gradient_sigma=gg['sigma'],gradient_magnitude=gg['gradient'],delta_BIC=gg['bic']-ff['bic'],flat_converged=ff['success'],gradient_converged=gg['success'],flat_bound=ff['bound'],gradient_bound=gg['bound']))
 if (j+1)%20==0:print('completed',j+1,flush=True)
T=pd.DataFrame(rows);T.to_csv(P/'bootstrap_replicates.csv',index=False)
summary={'status':'EXPLORATORY, nonparametric row bootstrap, not preregistered','seed':7142026,'replicates':N,'sample_size':len(v),'resampling':'139 rows with replacement; refit both velocity-only mixtures; two initializations for gradient model','quantiles':{k:{str(q):float(T[k].quantile(q)) for q in [.025,.5,.975]} for k in ['flat_sigma','gradient_sigma','gradient_magnitude','delta_BIC']},'fraction_delta_BIC_below_zero':float((T.delta_BIC<0).mean()),'fraction_delta_BIC_below_minus_six':float((T.delta_BIC< -6).mean()),'converged_both':int((T.flat_converged&T.gradient_converged).sum()),'at_bounds_any':int((T.flat_bound|T.gradient_bound).sum()),'caveats':['Bootstrap percentiles are descriptive stability intervals, not calibrated confidence/credible intervals','No survey selection function, spatial prior, or metallicity membership model','Gaussian foreground assumption and velocity-only membership remain','Mixture likelihood can be multimodal; two starts do not prove global optimum','This does not fit Jeans gravity or a 3D Hessian']}
(P/'bootstrap_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
