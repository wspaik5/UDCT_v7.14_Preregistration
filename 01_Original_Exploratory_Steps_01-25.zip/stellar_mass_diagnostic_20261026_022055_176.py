"""UDCT v7.14 exploratory fixed-total-mass profile likelihood; not a stellar-mass measurement."""
import numpy as np,pandas as pd,json,hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import interp1d
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1/data_audit.csv')
v=D.HRV.to_numpy(float); e=D.e_HRV.to_numpy(float)
ra0,dec0=37.389,-79.3089; a=53.3; dist=27600.; G=4.30091e-3; Mref=1e6
R=np.hypot((D.RAdeg.to_numpy()-ra0)*np.cos(np.deg2rad(dec0)),D.DEdeg.to_numpy()-dec0)*np.pi/180*dist
r=np.geomspace(1e-4,2e6,10000); z=np.r_[0.,np.geomspace(1e-4,1e5,1000)]; rr=np.hypot(R[:,None],z[None,:]); nu=(1+(r/a)**2)**-2.5; nu_los=(1+(rr/a)**2)**-2.5; denom=2*np.trapezoid(nu_los,z,axis=1)
Mr=Mref*r**3/(r*r+a*a)**1.5
mass_grid=[1e3,3e3,1e4,3e4,1e5,3e5,5.324885882745674e5,8e5,1e6]
rows=[]
for beta in [-1.,-.5,0.]:
 integ=nu*G*Mr/r**2*r**(2*beta)
 cum=cumulative_trapezoid(integ,r,initial=0); sr2=np.maximum(cum[-1]-cum,0)*r**(-2*beta)/nu
 spl=interp1d(np.log(r),np.maximum(sr2,0),bounds_error=False,fill_value=(sr2[0],0.))
 los=2*np.trapezoid(nu_los*spl(np.log(np.maximum(rr,1e-4)))*(1-beta*R[:,None]**2/(rr**2+1e-30)),z,axis=1)/denom
 assert np.all(los>0)
 for mass in mass_grid:
  vm=los*(mass/Mref)+e*e
  def objective(t):
   mu,fgmu,fgs,logit=t; p=expit(logit); vf=fgs**2+e*e
   member=np.log(p)-.5*(np.log(2*np.pi*vm)+(v-mu)**2/vm)
   fore=np.log1p(-p)-.5*(np.log(2*np.pi*vf)+(v-fgmu)**2/vf)
   return float(-np.sum(logsumexp(np.stack((member,fore)),axis=0)))
  bounds=[(65,100),(-100,200),(25,350),(-8,1.5)]
  rng=np.random.default_rng(714+int(mass)+int((beta+1)*10))
  starts=[[80.5,82,104,-1.3],[81,80,110,-2.5],[80,85,100,-4]]
  starts += [[rng.uniform(76,85),rng.uniform(60,100),rng.uniform(70,150),rng.uniform(-4,-.8)] for _ in range(3)]
  fits=[minimize(objective,s,method='L-BFGS-B',bounds=bounds,options={'maxiter':500,'ftol':1e-10}) for s in starts]
  fit=min(fits,key=lambda f:f.fun); t=fit.x
  rows.append({'beta':beta,'total_mass_Msun':mass,'nll':fit.fun,'member_fraction':float(expit(t[3])),'member_mean_kms':t[0],'foreground_sigma_kms':t[2],'success':bool(fit.success),'successful_starts':sum(f.success for f in fits),'member_fraction_at_lower_bound':abs(t[3]-bounds[3][0])<.001,'sigma_los_center_kms':float(np.sqrt(np.interp(0,R,los)*mass/Mref)) if False else float(np.sqrt(np.interp(0,np.sort(R),los[np.argsort(R)])*mass/Mref))})
  print(beta,mass,round(fit.fun,3),round(float(expit(t[3])),4),flush=True)
res=pd.DataFrame(rows); res['delta_2logL_vs_best_same_beta']=res.groupby('beta').nll.transform(lambda s:2*(s-s.min()))
res.to_csv(P/'fixed_mass_profile.csv',index=False)
summary={'status':'PRE-PREREGISTRATION EXPLORATORY','source_sha256':hashlib.sha256((P.parent.parent/'table2.txt').read_bytes()).hexdigest(),'model':'139-star velocity-only Gaussian member/foreground mixture, Plummer tracer and total Plummer potential, fixed beta and fixed total gravitating mass, foreground reoptimized','mass_grid':'hypothetical fixed total gravitating masses; NOT measured stellar masses or luminosity-derived masses','distance_kpc':27.6,'radius_pc':a,'center':[ra0,dec0],'best_by_beta':{},'warnings':['Mass is fixed TOTAL gravitating mass, not stellar mass derived from photometry','A small member fraction can make the likelihood effectively ignore the narrow Hydrus I component','Likelihood-ratio curves are nonstandard near mixture boundaries; no Wilks confidence intervals claimed','Same in-sample observations as previous explorations; no confirmation','No 3D Hessian, modified gravity, spatial/chemical membership, or distribution function positivity proof']}
for beta,g in res.groupby('beta'):
 b=g.loc[g.nll.idxmin()]; summary['best_by_beta'][str(beta)]={'mass_Msun':float(b.total_mass_Msun),'nll':float(b.nll),'member_fraction':float(b.member_fraction),'fixed_mass_1e4_delta_2logL':float(g.loc[g.total_mass_Msun==1e4,'delta_2logL_vs_best_same_beta'].iloc[0])}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
