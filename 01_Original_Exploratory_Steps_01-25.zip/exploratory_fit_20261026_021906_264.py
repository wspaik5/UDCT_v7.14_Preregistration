import pandas as pd, numpy as np, json
from scipy.optimize import minimize
from scipy.special import expit
from pathlib import Path
p=Path(__file__).parent
df=pd.read_csv(p/'data_audit.csv')
res={}
for label, mask in [('odds_gt_0',df.logodds>0),('odds_gt_ln9',df.logodds>np.log(9)),('odds_gt_ln99',df.logodds>np.log(99)),('odds_gt_0_err_lt_10',(df.logodds>0)&(df.e_HRV<10))]:
 d=df[mask];v=d.HRV.to_numpy();e=d.e_HRV.to_numpy()
 def nll(t):
  mu,s=t; var=e*e+s*s
  return .5*np.sum(np.log(2*np.pi*var)+(v-mu)**2/var)
 opt=minimize(nll,[np.median(v),2.7],bounds=[(None,None),(0,100)],method='L-BFGS-B')
 res[label]={'n':len(d),'ids':d.ID.astype(int).tolist(),'mean_velocity':float(opt.x[0]),'intrinsic_sigma':float(opt.x[1]),'nll':float(opt.fun),'observed_velocity_range':[float(v.min()),float(v.max())]}
print(json.dumps(res,indent=2));(p/'exploratory_fit.json').write_text(json.dumps(res,indent=2)+'\n')
