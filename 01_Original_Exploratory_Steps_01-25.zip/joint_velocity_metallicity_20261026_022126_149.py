"""Exploratory joint velocity + metallicity mixture; no published logodds used."""
import numpy as np, pandas as pd, json, hashlib
from pathlib import Path
from scipy.optimize import minimize
from scipy.special import logsumexp,expit
P=Path(__file__).resolve().parent
D=pd.read_csv(P.parent/'run1'/'data_audit.csv')
valid=np.isfinite(D[['HRV','e_HRV','FeH','e_FeH','RAdeg','DEdeg']]).all(axis=1)&(D.e_HRV>0)&(D.e_FeH>0)
df=D.loc[valid].copy(); n=len(df)
v=df.HRV.to_numpy(float);ev=df.e_HRV.to_numpy(float);z=df.FeH.to_numpy(float);ez=df.e_FeH.to_numpy(float)
ra0,dec0=37.389,-79.3089
x=(df.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0))*60
y=(df.DEdeg.to_numpy(float)-dec0)*60

def gauss(a,mean,sigma2):return -.5*(np.log(2*np.pi*sigma2)+(a-mean)**2/sigma2)
def solve(grad=False,seed=714,starts=9):
 # member mean velocity, sigma velocity, foreground velocity mean/sigma,
 # member FeH mean/sigma, foreground FeH mean/sigma, mixture logit; optional velocity gradient
 bounds=[(65,100),(.05,15),(-100,200),(25,350),(-3.8,-1.0),(.03,1.2),(-3.5,0.5),(.1,2.5),(-5,1.5)]+([(-2,2),(-2,2)] if grad else [])
 def components(t):
  mu,sv,fmu,fsv,mz,sz,fz,fsz,lp=t[:9]
  mmean=mu+(t[9]*x+t[10]*y if grad else 0)
  a=gauss(v,mmean,sv**2+ev**2)+gauss(z,mz,sz**2+ez**2)+np.log(expit(lp))
  b=gauss(v,fmu,fsv**2+ev**2)+gauss(z,fz,fsz**2+ez**2)+np.log(expit(-lp))
  return a,b
 def obj(t):
  a,b=components(t);return -float(logsumexp(np.stack([a,b]),axis=0).sum())
 rng=np.random.default_rng(seed);out=[]
 for i in range(starts):
  init=np.array([80+rng.normal(0,2),rng.uniform(1.5,4.5),rng.uniform(30,90),rng.uniform(70,140),rng.uniform(-2.8,-2.0),rng.uniform(.15,.6),rng.uniform(-1.5,-.5),rng.uniform(.5,1.2),rng.uniform(-2,-.7)]+([rng.normal(0,.1),rng.normal(0,.1)] if grad else []))
  r=minimize(obj,init,method='L-BFGS-B',bounds=bounds,options={'maxiter':700,'ftol':1e-9});out.append(r)
 best=min(out,key=lambda r:r.fun);a,b=components(best.x);p=np.exp(a-logsumexp(np.stack([a,b]),axis=0));t=best.x
 return {'nll':float(best.fun),'bic':float(2*best.fun+len(t)*np.log(n)),'converged':bool(best.success),'parameters':dict(zip(['member_v','member_v_sigma','foreground_v','foreground_v_sigma','member_FeH','member_FeH_sigma','foreground_FeH','foreground_FeH_sigma','mixture_logit']+(['gradient_x','gradient_y'] if grad else []),map(float,t))),'p_sum':float(p.sum()),'p_gt_half':int((p>.5).sum()),'p_gt_0_9':int((p>.9).sum()),'at_bound':bool(any(abs(a-lo)<1e-3 or abs(a-hi)<1e-3 for a,(lo,hi) in zip(t,bounds)))},p
flat,p0=solve();gradient,p1=solve(True)
result={'status':'Exploratory only; neither preregistered nor independent membership verification','n_input':len(D),'n_complete':n,'data_sha256':hashlib.sha256((P.parent/'run1'/'data_audit.csv').read_bytes()).hexdigest(),'model':'independent Gaussian v and FeH within each mixture component; measurement errors added in quadrature; no logodds','flat':flat,'gradient':gradient,'delta_bic_gradient_minus_flat':gradient['bic']-flat['bic'],'limitations':['FeH and velocity may be correlated by sample selection; independence is an approximation','No spatial selection-function or CMD/photometry model','Foreground metallicity Gaussian is simplified','Not an independently confirmed member catalog','Model comparison across velocity-only and joint likelihood is not valid by raw BIC because outcomes differ']}
(P/'results.json').write_text(json.dumps(result,indent=2)+'\n')
pd.DataFrame({'ID':df.ID,'RAdeg':df.RAdeg,'DEdeg':df.DEdeg,'HRV':v,'e_HRV':ev,'FeH':z,'e_FeH':ez,'p_joint_flat':p0,'p_joint_gradient':p1}).to_csv(P/'joint_membership.csv',index=False)
print(json.dumps(result,indent=2))
