import numpy as np,pandas as pd,json
from scipy.optimize import minimize
from pathlib import Path
p=Path(__file__).resolve().parent
df=pd.read_csv(p/'data_audit.csv')
# Exploratory only: published logodds depend on velocities. Fixed tangent-plane center from median of ALL observed coordinates.
ra0=float(df.RAdeg.median()); dec0=float(df.DEdeg.median())
rad=np.pi/180
out={'scope':'exploratory; velocity-informed logodds selections; not independent observational confirmation','center_deg':[ra0,dec0],'selection':{}}
for name,threshold in [('odds_gt_0',0),('odds_gt_ln9',np.log(9)),('odds_gt_ln99',np.log(99))]:
 d=df.loc[df.logodds>threshold].copy();v=d.HRV.to_numpy(float);e=d.e_HRV.to_numpy(float)
 x=(d.RAdeg.to_numpy(float)-ra0)*np.cos(dec0*rad)*60;y=(d.DEdeg.to_numpy(float)-dec0)*60
 def fit(gradient):
  def nll(t):
   mu=t[0];s=t[1];model=mu+(t[2]*x+t[3]*y if gradient else 0)
   var=e*e+s*s
   return float(.5*np.sum(np.log(2*np.pi*var)+(v-model)**2/var))
  start=[float(np.median(v)),2.7]+([0.,0.] if gradient else [])
  bounds=[(None,None),(0.,30.)]+([(-20.,20.),(-20.,20.)] if gradient else [])
  opt=minimize(nll,start,bounds=bounds,method='L-BFGS-B',options={'maxiter':3000,'ftol':1e-12})
  k=4 if gradient else 2;n=len(v)
  return {'converged':bool(opt.success),'parameters':opt.x.tolist(),'nll':float(opt.fun),'BIC':float(k*np.log(n)+2*opt.fun),'AIC':float(2*k+2*opt.fun)}
 flat=fit(False);grad=fit(True)
 out['selection'][name]={'n':len(d),'flat':flat,'gradient':grad,'delta_BIC_gradient_minus_flat':grad['BIC']-flat['BIC'],'gradient_magnitude_kms_per_arcmin':float(np.hypot(grad['parameters'][2],grad['parameters'][3])),'radial_span_arcmin':float(np.max(np.hypot(x,y)))}
(p/'gradient_sensitivity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
