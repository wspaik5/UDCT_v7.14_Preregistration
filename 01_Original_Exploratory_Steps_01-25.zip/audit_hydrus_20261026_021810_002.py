#!/usr/bin/env python3
"""CDS fixed-width Hydrus I table2.dat QC only; no physical fit."""
import csv, hashlib, json, math, sys
from pathlib import Path

# CDS J/MNRAS/479/5343 ReadMe, 1-indexed inclusive byte ranges.
FIELDS = {
 'ID': (1,3), 'RAdeg':(5,12), 'DEdeg':(14,22), 'SNR':(24,27),
 'HRV':(29,34), 'e_HRV':(36,40), 'Teff':(42,45),
 'e_Teff':(47,50), 'loggmean':(52,55), 'e_loggmean':(57,60),
 'FeH':(62,66), 'e_FeH':(68,71), 'gmag':(73,77),
 'rmag':(79,83), 'logodds':(85,106), 'e_logodds':(108,129)
}

def parse(line):
    out={}
    for key,(a,b) in FIELDS.items():
        raw=line[a-1:b].strip()
        out[key]=None if raw in ('','-') else (int(raw) if key in ('ID','Teff','e_Teff') else float(raw))
    return out

def main(path):
    p=Path(path)
    data=p.read_bytes()
    lines=[line for line in data.decode('ascii').splitlines() if line.strip()]
    rows=[parse(line) for line in lines]
    ids=[r['ID'] for r in rows]
    counts={key:sum(r[key] is None for r in rows) for key in FIELDS}
    good=[r for r in rows if r['HRV'] is not None and r['e_HRV'] is not None and 0<r['e_HRV']<10]
    invalid=[r['ID'] for r in rows if (r['e_HRV'] is not None and r['e_HRV']<=0) or (r['RAdeg'] is not None and not 0<=r['RAdeg']<360) or (r['DEdeg'] is not None and not -90<=r['DEdeg']<=90)]
    audit={
      'source':'CDS J/MNRAS/479/5343 table2.dat',
      'sha256':hashlib.sha256(data).hexdigest(),
      'row_count':len(rows), 'expected_row_count':139,
      'row_count_matches_catalogue':len(rows)==139,
      'duplicate_ID_count':len(ids)-len(set(ids)),
      'missing_by_column':counts,
      'valid_velocity_error_lt_10_count':len(good),
      'invalid_coordinate_or_error_ids':invalid,
      'membership_thresholds_are_not_applied':True,
      'interpretation':'Data ingestion QC only; no likelihood, Jeans or Hessian validation.'
    }
    p.with_name('data_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    with p.with_name('data_audit.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(FIELDS))
        writer.writeheader();writer.writerows(rows)
    print(json.dumps(audit,indent=2))

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit('Usage: python audit_hydrus.py table2.dat')
    main(sys.argv[1])
