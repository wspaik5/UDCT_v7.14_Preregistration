"""Exploratory velocity-only mixture fit, no published logodds used in likelihood."""
import numpy as np, pandas as pd, json, hashlib
from scipy.optimize import minimize
from scipy.special import logsumexp, expit
from pathlib import Path
P=Path(__file__).resolve().parent
source=P.parent.parent/'table2.txt'
df=pd.read_csv(P.parent/'run1'/'data_audit.csv')
ra0=float(df.RAdeg.median());dec0=float(df.DEdeg.median())
v=df.HRV.to_numpy(float); e=df.e_HRV.to_numpy(float)
x=(df.RAdeg.to_numpy(float)-ra0)*np.cos(np.deg2rad(dec0))*60
y=(df.DEdeg.to_numpy(float)-dec0)*60
# Gaussian mixture: member with intrinsic dispersion + heteroscedastic errors;
# foreground broad Gaussian. No spatial membership prior and no logodds in fit.
def solve(gradient, seed=714):
 def objective(t):
  mu,s,fgmu,fgs,logit=t[:5];pi=expit(logit)
  model=mu+(t[5]*x+t[6]*y if gradient else 0)
  a=-.5*(np.log(2*np.pi*(s*s+e*e))+(v-model)**2/(s*s+e*e))+np.log(pi)
  b=-.5*(np.log(2*np.pi*(fgs*fgs+e*e))+(v-fgmu)**2/(fgs*fgs+e*e))+np.log1p(-pi)
  return -float(np.sum(logsumexp(np.stack([a,b]),axis=0)))
 rng=np.random.default_rng(seed); candidates=[]
 bounds=[(65,100),(.05,20),(-100,200),(25,350),(-5,1.5)]+([(-2,2),(-2,2)] if gradient else [])
 for i in range(16):
  t=[80+rng.normal(0,4),rng.uniform(1,8),rng.uniform(0,90),rng.uniform(60,160),rng.uniform(-2.5,-.5)]+([rng.normal(0,.15),rng.normal(0,.15)] if gradient else [])
  res=minimize(objective,t,method='L-BFGS-B',bounds=bounds,options={'maxiter':1200,'ftol':1e-10})
  candidates.append(res)
 res=min(candidates,key=lambda r:r.fun); n=len(v); k=len(res.x)
 mu,s,fgmu,fgs,logit=res.x[:5];pi=expit(logit)
 member_model=mu+(res.x[5]*x+res.x[6]*y if gradient else 0)
 la=-.5*(np.log(2*np.pi*(s*s+e*e))+(v-member_model)**2/(s*s+e*e))+np.log(pi)
 lb=-.5*(np.log(2*np.pi*(fgs*fgs+e*e))+(v-fgmu)**2/(fgs*fgs+e*e))+np.log1p(-pi)
 p=np.exp(la-logsumexp(np.stack([la,lb]),axis=0))
 return {'converged':bool(res.success),'nll':float(res.fun),'BIC':float(2*res.fun+k*np.log(n)),'AIC':float(2*res.fun+2*k),'parameters':{'member_mean_kms':float(mu),'member_intrinsic_sigma_kms':float(s),'foreground_mean_kms':float(fgmu),'foreground_intrinsic_sigma_kms':float(fgs),'mixture_member_fraction':float(pi),'gradient_x_kms_arcmin':float(res.x[5]) if gradient else 0.,'gradient_y_kms_arcmin':float(res.x[6]) if gradient else 0.},'sum_member_probabilities':float(p.sum()),'n_p_member_gt_half':int((p>.5).sum()),'n_p_member_gt_0_9':int((p>.9).sum()),'at_parameter_bound':any(abs(z-b[0])<1e-3 or abs(z-b[1])<1e-3 for z,b in zip(res.x,bounds))},p
flat,pflat=solve(False); grad,pgrad=solve(True)
out={'status':'EXPLORATORY; not preregistered, not Jeans/Hessian, not independent physical validation','data_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'n_stars':len(df),'center_median_deg':[ra0,dec0],'model':'two heteroscedastic Gaussian velocity components, no published logodds in likelihood, no spatial membership prior','flat':flat,'gradient':grad,'delta_BIC_gradient_minus_flat':grad['BIC']-flat['BIC'],'warnings':['Gaussian foreground is a simplification; mixture identifiability and selection function untested','No membership probabilities treated as ground truth','Results are in-sample exploratory; no uncertainty intervals or posterior predictive validation','Original sample may be preselected by the discovery survey; not a full survey selection model']}
(P/'mixture_results.json').write_text(json.dumps(out,indent=2)+'\n')
pd.DataFrame({'ID':df.ID,'HRV':v,'e_HRV':e,'p_member_flat_exploratory':pflat,'p_member_gradient_exploratory':pgrad}).to_csv(P/'mixture_membership_diagnostics.csv',index=False)
print(json.dumps(out,indent=2))
